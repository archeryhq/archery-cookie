# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['archery_cookie']

package_data = \
{'': ['*']}

install_requires = \
['archery-secret @ git+https://github.com/archeryhq/archery-secret.git@main',
 'redis>=3.5.3,<4.0.0']

setup_kwargs = {
    'name': 'archery-cookie',
    'version': '0.1.0',
    'description': 'Cookies from Archery person',
    'long_description': None,
    'author': 'Enio Climaco Sales Junior',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
